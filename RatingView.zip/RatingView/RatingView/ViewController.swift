//
//  ViewController.swift
//  RatingView
//
//  Created by Ayush Mehra on 17/04/20.
//  Copyright © 2020 Ayush Mehra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var viewRating: StarRateView!
    @IBOutlet weak var lblData: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        viewRating.actionBlock = {
            debugPrint(self.viewRating.rateCount)
            
        }
        
        // Do any additional setup after loading the view.
    }


}

